/**
 * Created by said on 3/26/2016.
 */
public interface CustomerDao {

    
        void save(Customer customer);
        void update(Customer customer);
        void delete(Customer customer);
        Customer findByCustomerCode(long customerCode);

    
}
