import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by said on 3/26/2016.
 */
public class App
{
    public static void main( String[] args )
    {
        ApplicationContext appContext =
                new ClassPathXmlApplicationContext("config/BeanLocations.xml");

        CustomerBo customerBo = (CustomerBo)appContext.getBean("customerBo");

        /** insert **/
        Customer customer = new Customer();
        customer.setCustomerID(345);
        customer.setCustomerEmail("customer345@company.com");
        customer.setCustomerCreditLimit((float) 235.50);
        // January 3rd 2009
        SimpleDateFormat dateFormatter = new SimpleDateFormat("MMMM d'rd' yyyy");

        String dateInString = "January 3rd 2009";
        Date dateObject = null;

        try {

            dateObject = dateFormatter.parse(dateInString);

            //System.out.println(dateObject);
            //System.out.println(dateFormatter.format(dateObject));

        } catch (ParseException e) {
            e.printStackTrace();
        }

        customer.setCustomerSince(dateObject);


        customerBo.save(customer);

        /** select **/
        Customer customer2 = customerBo.findByCustomerCode(345);
        System.out.println(customer2);

    }
}