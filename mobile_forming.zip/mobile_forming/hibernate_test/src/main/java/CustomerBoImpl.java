/**
 * Created by said on 3/26/2016.
 */
public class CustomerBoImpl implements CustomerBo{


        CustomerDao customerDao;

        public void setCustomerDao(CustomerDao CustomerDao) {
            this.customerDao = CustomerDao;
        }

        public void save(Customer customer){
            customerDao.save(customer);
        }

        public void update(Customer customer){
            customerDao.update(customer);
        }

        public void delete(Customer customer){
            customerDao.delete(customer);
        }

        public Customer findByCustomerCode(long customerCode){
            return customerDao.findByCustomerCode(customerCode);
        }
    
}
