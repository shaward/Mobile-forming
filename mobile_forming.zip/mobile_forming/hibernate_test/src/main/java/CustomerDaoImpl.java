import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.util.List;

/**
 * Created by said on 3/26/2016.
 */
public class CustomerDaoImpl extends HibernateDaoSupport implements CustomerDao{


        public void save(Customer customer){
            getHibernateTemplate().save(customer);
        }

        public void update(Customer customer){
            getHibernateTemplate().update(customer);
        }

        public void delete(Customer customer){
            getHibernateTemplate().delete(customer);
        }

        public Customer findByCustomerCode(long customerCode){
            List list = getHibernateTemplate().find(
                    "from Customer where CustomerId=?",customerCode
            );
            return (Customer)list.get(0);
        }


}
