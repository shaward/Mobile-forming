import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

//import org.json.simple.JSONObject;

@XmlRootElement
public class Customer implements Serializable {
	
	  long customerID ;  
	  String customerEmail ; 
	  float customerCreditLimit ; 
	  Date customerSince; //  date [ January 3rd 2009]


	public long getCustomerID() {
		return customerID;
	}

	@XmlElement
	public void setCustomerID(long customerID) {
		this.customerID = customerID;
	}


	public String getCustomerEmail() {
		return customerEmail;
	}

	@XmlElement
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}


	public float getCustomerCreditLimit() {
		return customerCreditLimit;
	}

	@XmlElement
	public void setCustomerCreditLimit(float customerCreditLimit) {
		this.customerCreditLimit = customerCreditLimit;
	}


	public Date getCustomerSince() {
		return customerSince;
	}

	@XmlElement
	public void setCustomerSince(Date customerSince) {
		this.customerSince = customerSince;
	}

	@Override
	public String toString() {
		return "Customer {customerID=" + customerID + ",customerEmail=" +customerEmail + ", customerCreditLimit="
				+ customerCreditLimit + ", customerSince =" + customerSince + "}";
	}


}
		


		
			

