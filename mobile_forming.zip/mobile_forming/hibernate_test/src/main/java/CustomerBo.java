/**
 * Created by said on 3/26/2016.
 */
public interface CustomerBo {
    

        void save(Customer Customer);
        void update(Customer Customer);
        void delete(Customer Customer);
        Customer findByCustomerCode(long CustomerCode);

}
