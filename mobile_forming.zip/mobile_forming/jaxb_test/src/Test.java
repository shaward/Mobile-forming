


import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] days = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
		for ( int i = 0; i < days.length; i++){
		    String reverse = new StringBuffer(days[i]).reverse().toString();
		    days[i] = reverse;
		    
		}
		
		for (int i = 0; i < days.length;  i++) {
	         if(i != 0){
	            System.out.print(", ");
	         }
	         System.out.print(days[i]);                     
	      }
	      System.out.println();
	

		List <String> dayslist = Arrays.asList(days);
		Collections.sort(dayslist);
		for (int i = 0; i < dayslist.size();  i++) {
	         if(i != 0){
	            System.out.print(", ");
	         }
	         System.out.print(dayslist.get(i));                     
	      }
	      System.out.println();

		Collections.reverse(dayslist);
		for (int i = 0; i < dayslist.size();  i++) {
		         if(i != 0){
		            System.out.print(", ");
		         }
		         System.out.print(dayslist.get(i));                     
		      }
		      System.out.println();
		   }
	

}
