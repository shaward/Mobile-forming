package test1;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import com.google.gson.Gson;
//import org.json.simple.JSONObject;


import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@XmlRootElement
public class Customer {
	
	  long customerID ;  
	  String customerEmail ; 
	  float customerCreditLimit ; 
	  Date customerSince; //  date [ January 3rd 2009]


	public long getCustomerID() {
		return customerID;
	}

	@XmlElement
	public void setCustomerID(long customerID) {
		this.customerID = customerID;
	}


	public String getCustomerEmail() {
		return customerEmail;
	}

	@XmlElement
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}


	public float getCustomerCreditLimit() {
		return customerCreditLimit;
	}

	@XmlElement
	public void setCustomerCreditLimit(float customerCreditLimit) {
		this.customerCreditLimit = customerCreditLimit;
	}


	public Date getCustomerSince() {
		return customerSince;
	}

	@XmlElement
	public void setCustomerSince(Date customerSince) {
		this.customerSince = customerSince;
	}


	public static void main(String[] args) {
		
		Customer customer = new Customer();
		customer.setCustomerID(345);
		customer.setCustomerEmail("customer345@company.com");
		customer.setCustomerCreditLimit((float)235.50);
		// January 3rd 2009
		SimpleDateFormat dateFormatter = new SimpleDateFormat ( "MMMM d'rd' yyyy" );

		String dateInString = "January 3rd 2009";
		java.util.Date dateObject=null;

		try {

			dateObject = dateFormatter.parse ( dateInString );

			System.out.println( dateObject );
			System.out.println( dateFormatter.format ( dateObject ) );

		} catch ( ParseException e) {
			e.printStackTrace();
		}
		
			customer.setCustomerSince(dateObject);
		

		try {

		
		//File file = new File("C:\\file.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(Customer.class);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

		// output pretty printed
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

		//jaxbMarshaller.marshal(customer, file);
		jaxbMarshaller.marshal(customer, System.out);

	      } catch (JAXBException e) {
	    	  	e.printStackTrace();
	      }

	}
		
}

		
			

